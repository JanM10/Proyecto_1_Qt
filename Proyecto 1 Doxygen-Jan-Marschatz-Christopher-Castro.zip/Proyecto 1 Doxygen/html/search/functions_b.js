var searchData=
[
  ['localserver_583',['LocalServer',['../class_local_server.html#a5aa57d4e9cc566123b356d3c21ec04f7',1,'LocalServer']]]
];
