var searchData=
[
  ['base_5fiterator_669',['base_iterator',['../classnlohmann_1_1detail_1_1json__reverse__iterator.html#a6b2ef1d632fe49bfcc22fbd1abd62395',1,'nlohmann::detail::json_reverse_iterator']]],
  ['binary_5ft_670',['binary_t',['../classnlohmann_1_1basic__json.html#ad6c955145bebde84d93991ffed7cd389',1,'nlohmann::basic_json']]],
  ['boolean_5ft_671',['boolean_t',['../classnlohmann_1_1basic__json.html#a44fd1a12c9c54623c942b430e7a72937',1,'nlohmann::basic_json']]]
];
