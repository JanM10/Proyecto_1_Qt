var searchData=
[
  ['initializer_5flist_5ft_681',['initializer_list_t',['../classnlohmann_1_1basic__json.html#ac569f292a070dfd2f6b69c16e746095a',1,'nlohmann::basic_json']]],
  ['invalid_5fiterator_682',['invalid_iterator',['../classnlohmann_1_1basic__json.html#a6ccc9788413fd58de998fe92743cb4aa',1,'nlohmann::basic_json']]],
  ['iterator_683',['iterator',['../classnlohmann_1_1basic__json.html#aa549b2b382916b3baafb526e5cb410bd',1,'nlohmann::basic_json']]],
  ['iterator_5fcategory_684',['iterator_category',['../classnlohmann_1_1detail_1_1iter__impl.html#ad9e091f5c70b34b5b1abc1ab15fd9106',1,'nlohmann::detail::iter_impl']]]
];
